import type { EmailTemplateParams } from '@/types';

class EmailJSResponseStatus {
    public status: number;
    public text: string;

    constructor(httpResponse: XMLHttpRequest) {
        this.status = httpResponse.status;
        this.text = httpResponse.responseText;
    }
}

const sendPost = (
    url: string,
    data: string,
    headers: Record<string, string> = {},
): Promise<EmailJSResponseStatus> => {
    return new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();

        xhr.addEventListener('load', ({ target }) => {
            const responseStatus = new EmailJSResponseStatus(target as XMLHttpRequest);
            if (responseStatus.status === 200 || responseStatus.text === 'OK') {
                resolve(responseStatus);
            } else {
                reject(responseStatus);
            }
        });

        xhr.addEventListener('error', ({ target }) => {
            reject(new EmailJSResponseStatus(target as XMLHttpRequest));
        });

        xhr.open('POST', 'https://api.emailjs.com' + url, true);
        
        Object.keys(headers).forEach((key) => {
            xhr.setRequestHeader(key, headers[key]);
        });
        
        xhr.send(data);
    });
};

const validateTemplateID = (userID?: string, serviceID?: string, templateID?: string) => {
    if (!templateID) {
        throw 'The template ID is required. Visit https://dashboard.emailjs.com/admin/templates';
    }
    return true;
};

export const send = (
    serviceID: string,
    templateID: string,
    templateParams?: EmailTemplateParams,
    userID?: string,
): Promise<EmailJSResponseStatus> => {
    validateTemplateID(userID, serviceID, templateID);

    const emailData = {
        lib_version: '3.2.0',
        user_id: userID,
        service_id: serviceID,
        template_id: templateID,
        template_params: templateParams,
    };

    return sendPost('/api/v1.0/email/send', JSON.stringify(emailData), {
        'Content-type': 'application/json',
    });
};