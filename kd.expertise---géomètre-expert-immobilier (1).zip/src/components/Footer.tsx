import React from 'react';

const LogoWhite = () => (
    <a href="#Home" className="text-2xl font-extrabold text-white">
        KD<span className="text-orange-vif">.</span>Expertise
    </a>
);

const Footer: React.FC = () => {
    return (
        <footer className="bg-blue-deep text-slate-300">
            <div className="container mx-auto px-6 py-12">
                <div className="grid md:grid-cols-4 gap-8 text-center md:text-left">
                    <div className="space-y-4">
                        <LogoWhite />
                        <p>Kévin Delporte - Géomètre-Expert Immobilier</p>
                        <p>1470 Genappe, Belgique</p>
                        <p>Tél: 0470 94 15 88</p>
                        <p>Email: geometre1470@gmail.com</p>
                    </div>
                    <div className="space-y-2">
                        <h4 className="font-bold text-lg text-white mb-4">Navigation</h4>
                        <ul>
                            <li><a href="#Services" className="hover:text-orange-vif transition">Services</a></li>
                            <li><a href="#About" className="hover:text-orange-vif transition">À propos</a></li>
                            <li><a href="#Testimonials" className="hover:text-orange-vif transition">Avis</a></li>
                            <li><a href="#Contact" className="hover:text-orange-vif transition">Contact</a></li>
                        </ul>
                    </div>
                    <div className="space-y-2">
                        <h4 className="font-bold text-lg text-white mb-4">Légal</h4>
                        <ul>
                            <li><a href="#Legal" className="hover:text-orange-vif transition">Mentions Légales</a></li>
                            <li><a href="#Privacy" className="hover:text-orange-vif transition">Politique de confidentialité - RGPD</a></li>
                        </ul>
                    </div>
                    <div className="space-y-2">
                        <h4 className="font-bold text-lg text-white mb-4">Liens utiles</h4>
                         <ul>
                            <li><a href="https://www.wallonie.be/fr/demarches/sinformer-sur-le-bail-dhabitation" target="_blank" rel="noopener noreferrer" className="hover:text-orange-vif transition">Guide du bail d'habitation</a></li>
                            <li><a href="https://www.ejustice.just.fgov.be/cgi_loi/change_lg.pl?language=fr&la=F&cn=1997010825&table_name=loi" target="_blank" rel="noopener noreferrer" className="hover:text-orange-vif transition">Moniteur belge – Règles d'entretien</a></li>
                             <li><a href="https://www.notaires.be/acheter-louer/location/etat-des-lieux" target="_blank" rel="noopener noreferrer" className="hover:text-orange-vif transition">Notaire.be – État des lieux</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div className="bg-slate-950 py-4 text-center text-sm text-slate-400">
                <p>Copyright © 2024 kd-expertise.be - Tous droits réservés.</p>
            </div>
        </footer>
    );
};

export default Footer;