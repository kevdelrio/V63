
import React, { useState } from 'react';
import { calculatePrice } from '../services/bookingService';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

const PriceCalculator: React.FC = () => {
    const [inputs, setInputs] = useState({
        mission: 'locatif',
        typeBien: 'appartement',
        chambres: 1,
        sdb: 1,
        meuble: false,
        jardin: false,
        parking: false,
        cave: false,
        print: false,
        frais: '2parties',
        surface: 300,
    });
    
    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value, type } = e.target;
        const checked = (e.target as HTMLInputElement).checked;

        setInputs(prev => {
            const newInputs = { ...prev };
            if (type === 'checkbox') {
                (newInputs as any)[name] = checked;
            } else if (name === 'chambres' || name === 'sdb' || name === 'surface') {
                (newInputs as any)[name] = parseInt(value, 10);
            } else {
                (newInputs as any)[name] = value;
            }

            if (name === 'typeBien') {
                if (value === 'studio' || value === 'kot') {
                    newInputs.chambres = 0;
                } else if (value === 'entrepot') {
                    newInputs.chambres = 0;
                    newInputs.sdb = 0;
                } else {
                    if (newInputs.chambres === 0) newInputs.chambres = 1;
                    if (newInputs.sdb === 0) newInputs.sdb = 1;
                }
            }
            
            return newInputs;
        });
    };

    const { pricePerParty, total, basePrice } = calculatePrice({
        typeBien: inputs.typeBien as any,
        chambres: inputs.chambres,
        sdb: inputs.sdb,
        surface: inputs.surface,
        options: {
            meuble: inputs.meuble,
            jardin: inputs.jardin,
            parking: inputs.parking,
            cave: inputs.cave,
            print: inputs.print
        }
    });

    const showChambreSdb = inputs.typeBien === 'appartement' || inputs.typeBien === 'maison' || inputs.typeBien === 'villa';
    const showSdbOnly = inputs.typeBien === 'studio' || inputs.typeBien === 'kot';

    return (
        <div className="bg-blue-deep/5 backdrop-blur-sm rounded-xl p-6 md:p-8 max-w-4xl mx-auto shadow-lg border border-orange-vif/20">
            <h3 className="text-3xl font-bold mb-6 text-center text-blue-deep">Calculez le prix de votre état des lieux</h3>
            <div className="grid md:grid-cols-3 gap-8 items-start">
                <div className="md:col-span-2 space-y-6">
                    <div className="grid sm:grid-cols-2 gap-6">
                        <div>
                            <label className="block font-semibold text-slate-700 mb-1">Type de bien</label>
                            <select name="typeBien" onChange={handleChange} value={inputs.typeBien} className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-vif focus:border-transparent transition">
                                <option value="appartement">Appartement</option>
                                <option value="maison">Maison</option>
                                <option value="villa">Villa</option>
                                <option value="studio">Studio</option>
                                <option value="kot">Kot</option>
                                <option value="entrepot">Entrepôt / Commerce</option>
                            </select>
                        </div>

                        {showChambreSdb && (
                           <div>
                                <label className="block font-semibold text-slate-700 mb-1">Chambres</label>
                                <select name="chambres" onChange={handleChange} value={inputs.chambres} className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-vif focus:border-transparent transition">
                                    {Array.from(Array(6).keys()).map(i => <option key={i} value={i + 1}>{i + 1} chambre{i > 0 ? 's' : ''}</option>)}
                                </select>
                            </div>
                        )}
                        
                        {(showChambreSdb || showSdbOnly) && (
                           <div>
                                <label className="block font-semibold text-slate-700 mb-1">Salles de bain / douche</label>
                                <select name="sdb" onChange={handleChange} value={inputs.sdb} className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-vif focus:border-transparent transition">
                                    {[1, 2, 3, 4].map(i => <option key={i} value={i}>{i} salle{i > 1 ? 's' : ''} de bain</option>)}
                                </select>
                            </div>
                        )}

                        {inputs.typeBien === 'entrepot' && (
                             <div>
                                <label className="block font-semibold text-slate-700 mb-1">Surface (m²)</label>
                                <input type="number" name="surface" step="50" min="0" onChange={handleChange} value={inputs.surface} className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-vif focus:border-transparent transition"/>
                            </div>
                        )}
                    </div>
                    <div>
                        <p className="font-semibold text-slate-700 mb-2">Options supplémentaires :</p>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                            <label className="inline-flex items-center bg-white p-3 rounded-lg shadow-sm border border-transparent hover:border-orange-vif/50 cursor-pointer">
                                <input type="checkbox" name="meuble" checked={inputs.meuble} onChange={handleChange} className="h-5 w-5 text-orange-vif border-gray-300 rounded focus:ring-orange-vif mr-3" />
                                Bien meublé
                            </label>
                            <label className="inline-flex items-center bg-white p-3 rounded-lg shadow-sm border border-transparent hover:border-orange-vif/50 cursor-pointer">
                                <input type="checkbox" name="jardin" checked={inputs.jardin} onChange={handleChange} className="h-5 w-5 text-orange-vif border-gray-300 rounded focus:ring-orange-vif mr-3" />
                                Jardin / Terrasse
                            </label>
                             <label className="inline-flex items-center bg-white p-3 rounded-lg shadow-sm border border-transparent hover:border-orange-vif/50 cursor-pointer">
                                <input type="checkbox" name="parking" checked={inputs.parking} onChange={handleChange} className="h-5 w-5 text-orange-vif border-gray-300 rounded focus:ring-orange-vif mr-3" />
                                Parking / Garage
                            </label>
                             <label className="inline-flex items-center bg-white p-3 rounded-lg shadow-sm border border-transparent hover:border-orange-vif/50 cursor-pointer">
                                <input type="checkbox" name="cave" checked={inputs.cave} onChange={handleChange} className="h-5 w-5 text-orange-vif border-gray-300 rounded focus:ring-orange-vif mr-3" />
                                Cave
                            </label>
                             <label className="inline-flex items-center bg-white p-3 rounded-lg shadow-sm border border-transparent hover:border-orange-vif/50 cursor-pointer">
                                <input type="checkbox" name="print" checked={inputs.print} onChange={handleChange} className="h-5 w-5 text-orange-vif border-gray-300 rounded focus:ring-orange-vif mr-3" />
                                Version imprimée
                            </label>
                        </div>
                    </div>
                    <div>
                        <label className="block font-semibold text-slate-700 mb-1">Frais à charge</label>
                        <select name="frais" onChange={handleChange} value={inputs.frais} className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-vif focus:border-transparent transition">
                            <option value="2parties">Deux parties (propriétaire et locataire)</option>
                            <option value="1seulepartie">Une seule partie</option>
                        </select>
                    </div>
                </div>
                <div className="bg-white p-6 rounded-lg shadow-inner mt-6 md:mt-0">
                    <h4 className="text-xl font-bold text-blue-deep mb-4 text-center">Estimation du coût</h4>
                    {basePrice === 0 ? (
                        <p className="text-center text-2xl font-bold text-blue-deep">Sur devis</p>
                    ) : (
                        <div className="space-y-4">
                             {inputs.frais === '2parties' ? (
                                <>
                                    <div className="flex justify-between items-center text-lg">
                                        <span className="text-slate-600">Part Propriétaire :</span>
                                        <span className="font-semibold text-blue-deep">{pricePerParty.toFixed(2)} €</span>
                                    </div>
                                    <div className="flex justify-between items-center text-lg">
                                        <span className="text-slate-600">Part Locataire :</span>
                                        <span className="font-semibold text-blue-deep">{pricePerParty.toFixed(2)} €</span>
                                    </div>
                                </>
                            ) : (
                                <div className="flex justify-between items-center text-lg">
                                    <span className="text-slate-600">À votre charge :</span>
                                    <span className="font-semibold text-blue-deep">{total.toFixed(2)} €</span>
                                </div>
                            )}

                            <div className="border-t border-gray-200 my-2"></div>
                            <div className="flex justify-between items-center text-2xl font-bold">
                                <span className="text-orange-vif">Total TVAC :</span>
                                <span className="text-orange-vif">{total.toFixed(2)} €</span>
                            </div>
                        </div>
                    )}
                </div>
            </div>
            <p className="text-center text-xs text-slate-500 mt-6">Cette estimation est indicative. Un devis définitif sera fourni après analyse de votre demande.</p>
        </div>
    );
};

const Calculator: React.FC = () => {
    const [ref, isVisible] = useScrollAnimation();

    return (
        <section id="Calculator" ref={ref} className={`bg-white py-20 md:py-28 px-6 transition-all duration-1000 ease-out scroll-mt-24 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
            <div className="container mx-auto">
                <PriceCalculator />
            </div>
        </section>
    );
};


export default Calculator;